# Week 1 Tuesday — Tree Planning Foundations

## Goal

Build one generic `agent.py` that works on every public tree map in this package. Collect useful treasure, preserve enough energy to reach the exit, and avoid invalid actions.

## Rules

- The complete map, exit, treasure locations, and values are public.
- Walkable cells form a connected tree, so every pair of cells has one simple path.
- Every move costs 1 energy. `COLLECT` costs 1 energy.
- Entering the exit ends the run immediately.
- No exit means a score of 0.
- Submit only `agent.py`; the same file is evaluated on every map.

## Maps

| Map | Main lesson |
|---|---|
| `warmup.json` | Recover a path and collect a treasure on the route. |
| `two_branches.json` | Compare two treasure detours. |
| `greedy_trap.json` | The nearest treasure is not always the best choice. |
| `energy_budget.json` | Reserve enough energy for the exit. |

## Run

```bash
python -m treasure_explorer --map maps/warmup.json --agent agent.py --view
python -m treasure_explorer --map maps/greedy_trap.json --agent agent.py
python -m unittest discover -s tests -v
```

`--view` animates the agent in the terminal. Use `--delay 0.4` for a slower
animation, or add `--no-clear` to keep every frame in the terminal output.

## Suggested three-hour flow

1. Implement BFS or DFS and path reconstruction.
2. Reach the exit reliably on every map.
3. Compare treasure value with the complete detour cost.
4. Test one generic strategy on all four maps.
