import argparse
import json
from pathlib import Path

from .runner import run

p = argparse.ArgumentParser()
p.add_argument("--map", required=True)
p.add_argument("--agent", required=True)
p.add_argument("--replay")
p.add_argument("--view", action="store_true")
args = p.parse_args()
result, history = run(args.map, args.agent)
if args.view:
    for frame in history:
        print(f"{frame['turn']:03} {frame['from']} -> {frame['to']}  {frame['action']}  E={frame['energy']}")
if args.replay:
    Path(args.replay).write_text(json.dumps({"result": result, "history": history}, indent=2), encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))

