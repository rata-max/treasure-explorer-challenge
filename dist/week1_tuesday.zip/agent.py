"""One generic agent for every map in this stage. Students edit only this file."""

from collections import deque
from treasure_explorer.model import Action, Observation

MOVES = ((Action.MOVE_UP, -1, 0), (Action.MOVE_DOWN, 1, 0),
         (Action.MOVE_LEFT, 0, -1), (Action.MOVE_RIGHT, 0, 1))


def _path(obs: Observation, goal: tuple[int, int] | None) -> list[Action]:
    if goal is None:
        # Frontier exploration baseline for Week 3.
        unknown = {(r, c) for r, row in enumerate(obs.grid) for c, x in enumerate(row) if x == "?"}
        frontier = [(r, c) for r, row in enumerate(obs.grid) for c, x in enumerate(row)
                    if x not in "#?" and any((r+dr, c+dc) in unknown for _, dr, dc in MOVES)]
        goal = min(frontier, key=lambda p: abs(p[0]-obs.position[0])+abs(p[1]-obs.position[1]), default=obs.position)
    queue = deque([obs.position])
    parent = {obs.position: None}
    while queue:
        current = queue.popleft()
        if current == goal:
            break
        for action, dr, dc in MOVES:
            nxt = (current[0]+dr, current[1]+dc)
            if nxt in parent or not (0 <= nxt[0] < len(obs.grid) and 0 <= nxt[1] < len(obs.grid[0])):
                continue
            if obs.grid[nxt[0]][nxt[1]] in "#?":
                continue
            parent[nxt] = (current, action)
            queue.append(nxt)
    if goal not in parent:
        return []
    actions = []
    while goal != obs.position:
        previous, action = parent[goal]
        actions.append(action)
        goal = previous
    return list(reversed(actions))


def choose_action(obs: Observation) -> Action:
    here = next((t for t in obs.treasures if t.position == obs.position and not t.collected), None)
    if here:
        return Action.COLLECT
    # Safe baseline: reach the exit. Improve target selection and weighted search.
    path = _path(obs, obs.exit_position)
    return path[0] if path else Action.MOVE_RIGHT

