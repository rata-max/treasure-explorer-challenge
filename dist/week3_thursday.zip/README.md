# Week 3 Thursday — Hidden Final Challenge

Balance exploration, hidden treasure value, and safe exit. Public practice maps do not reveal the TA's hidden evaluation maps.

## Package contract

- Modify only the root-level `agent.py`.
- The same unchanged `agent.py` is evaluated independently on all 3 released maps.
- Partial observations are cumulative within a run.
- Entering the exit ends the run immediately. A run without a successful exit scores zero.
- Score after exit: `50 + treasure value + remaining energy - 5 × invalid actions`.
- Terrain entry cost: normal/start/exit/treasure 1, mud 4, water 7. `COLLECT` costs 1.

## Run

```powershell
python -m treasure_explorer --map maps/<map-name>.json --agent agent.py --view
```

Run all maps in PowerShell:

```powershell
Get-ChildItem maps/*.json | ForEach-Object { python -m treasure_explorer --map $_.FullName --agent agent.py }
```

Run tests:

```powershell
python -m unittest discover -s tests -v
```
