# Week 1 Thursday — Global Tree Optimization

## Goal

Extend Tuesday's agent into a global planner. Select a feasible treasure subset and visit order while accounting for shared tree paths and the final route to the exit.

## Rules

- All Tuesday rules and the same `Observation`/`Action` API remain in effect.
- The map and treasure values remain public; uncertainty is not part of Week 1.
- Treasure branches can share travel cost and cannot always be priced as independent round trips.
- Nearest-first, highest-value-first, and isolated value-to-cost greedy rules are not guaranteed to be optimal.
- The submitted `agent.py` must run unchanged on all five maps.

## Maps

| Map | Main lesson |
|---|---|
| `shared_branch.json` | Two treasures share most of a detour. |
| `value_trap.json` | The highest-value treasure can reduce the final score. |
| `subset_order.json` | Choose both a subset and its visit order. |
| `large_tree.json` | Control a larger combinatorial search space. |
| `challenge.json` | Combine shared paths, value traps, and an energy limit. |

## Run

```bash
python -m treasure_explorer --map maps/shared_branch.json --agent agent.py --view
python -m treasure_explorer --map maps/challenge.json --agent agent.py
python -m unittest discover -s tests -v
```

## Suggested three-hour flow

1. Diagnose where a Tuesday greedy strategy fails.
2. Compress the tree into important terminals: current position, treasures, and exit.
3. Search treasure subsets and orders with DP, branch-and-bound, or a justified heuristic.
4. Compare score, exit rate, and runtime across all maps.

