"""Partial-observation baseline. One fresh module is loaded for each map run."""

from collections import deque
from treasure_explorer.model import Action, Observation

MOVES = ((Action.MOVE_UP, -1, 0), (Action.MOVE_DOWN, 1, 0),
         (Action.MOVE_LEFT, 0, -1), (Action.MOVE_RIGHT, 0, 1))
VISITED = set()


def paths_from(obs: Observation):
    queue = deque([obs.position])
    parent = {obs.position: None}
    distance = {obs.position: 0}
    while queue:
        current = queue.popleft()
        for action, dr, dc in MOVES:
            nxt = (current[0] + dr, current[1] + dc)
            if nxt in parent or not (0 <= nxt[0] < len(obs.grid) and 0 <= nxt[1] < len(obs.grid[0])):
                continue
            if obs.grid[nxt[0]][nxt[1]] in "#?":
                continue
            parent[nxt] = (current, action)
            distance[nxt] = distance[current] + 1
            queue.append(nxt)
    return parent, distance


def first_action(parent, start, goal):
    if goal not in parent or goal == start:
        return None
    current = goal
    actions = []
    while current != start:
        previous, action = parent[current]
        actions.append(action)
        current = previous
    return actions[-1]


def choose_action(obs: Observation) -> Action:
    VISITED.add(obs.position)
    parent, distance = paths_from(obs)
    if obs.exit_position is not None:
        action = first_action(parent, obs.position, obs.exit_position)
        if action is not None:
            return action

    # Move toward the farthest reachable frontier so each move reveals new cells.
    frontiers = []
    for position in parent:
        r, c = position
        touches_unknown = any(
            0 <= r + dr < len(obs.grid) and 0 <= c + dc < len(obs.grid[0])
            and obs.grid[r + dr][c + dc] == "?"
            for _, dr, dc in MOVES
        )
        if touches_unknown and position not in VISITED:
            frontiers.append(position)
    if frontiers:
        goal = min(frontiers, key=lambda p: distance[p])
        action = first_action(parent, obs.position, goal)
        if action is not None:
            return action

    # A deterministic fallback for a fully explored component.
    for action, dr, dc in MOVES:
        r, c = obs.position[0] + dr, obs.position[1] + dc
        if 0 <= r < len(obs.grid) and 0 <= c < len(obs.grid[0]) and obs.grid[r][c] not in "#?":
            return action
    return Action.MOVE_RIGHT
