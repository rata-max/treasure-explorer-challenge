"""Safe weighted-graph baseline. Improve this one file for every stage map."""

from heapq import heappop, heappush
from treasure_explorer.model import Action, Observation

MOVES = ((Action.MOVE_UP, -1, 0), (Action.MOVE_DOWN, 1, 0),
         (Action.MOVE_LEFT, 0, -1), (Action.MOVE_RIGHT, 0, 1))
COST = {".": 1, "S": 1, "E": 1, "T": 1, "M": 4, "W": 7}


def shortest_path(obs: Observation, goal: tuple[int, int]) -> list[Action]:
    frontier = [(0, obs.position)]
    distance = {obs.position: 0}
    parent = {obs.position: None}
    while frontier:
        cost, current = heappop(frontier)
        if cost != distance[current]:
            continue
        if current == goal:
            break
        for action, dr, dc in MOVES:
            nxt = (current[0] + dr, current[1] + dc)
            if not (0 <= nxt[0] < len(obs.grid) and 0 <= nxt[1] < len(obs.grid[0])):
                continue
            tile = obs.grid[nxt[0]][nxt[1]]
            if tile not in COST:
                continue
            candidate = cost + COST[tile]
            if candidate < distance.get(nxt, 10**9):
                distance[nxt] = candidate
                parent[nxt] = (current, action)
                heappush(frontier, (candidate, nxt))
    if goal not in parent:
        return []
    actions = []
    current = goal
    while current != obs.position:
        previous, action = parent[current]
        actions.append(action)
        current = previous
    return list(reversed(actions))


def choose_action(obs: Observation) -> Action:
    # This starter exits safely. Students add treasure subset and route planning.
    route = shortest_path(obs, obs.exit_position)
    return route[0]
